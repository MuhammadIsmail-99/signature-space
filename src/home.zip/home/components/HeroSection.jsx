// app/home/components/HeroSection.jsx
"use client"

import SearchBar from "../../Searchbar/search-bar"
import headerImg from "../../assets/header-image.jpg"
import "../styles/HeroSection.css"; // Import the CSS for HeroSection


export default function HeroSection() {
  return (
    <section
      className="hero"
      style={{
        backgroundImage: `url(${headerImg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="hero-overlay"></div>
      <div className="hero-container">
        <div className="hero-content">
          <h1 className="hero-title">
            <span className="hero-title-line">Find Your Perfect Stay,</span>
            <span className="hero-title-line">Anytime, Anywhere.</span>
          </h1>
          <p className="hero-subtitle">
            Discover amazing properties for your next adventure. From cozy apartments to luxury villas.
          </p>
          <div className="hero-search">
            <SearchBar />
          </div>
        </div>
      </div>
    </section>
  )
}
